# campuspedia-mqtt-test
Code for campuspedia x qlue event using mqtt with python

# installation prequisites
dont forget to install mosquitto for the broker 
```bash
sudo apt-get install mosquitto mosquitto-clients
```

and pip for the paho-mqtt
```python3
sudo apt-get install python3-pip # for those who haven't install pip in their system
sudo pip3 install paho-mqtt
```

